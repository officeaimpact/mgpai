"""API версии 1."""

from app.api.v1.endpoints.chat import router as chat_router

__all__ = ["chat_router"]
