# ENV_VARS — Переменные окружения

## 📋 Полный список переменных

Все переменные определены в `app/core/config.py` и читаются через `pydantic-settings` из файла `.env` или системного окружения.

---

## 🔧 Приложение

| Переменная | Тип | По умолчанию | Назначение |
|------------|-----|--------------|------------|
| `APP_NAME` | str | "MGP AI Assistant" | Название приложения (отображается в /docs) |
| `APP_VERSION` | str | "1.0.0" | Версия приложения |
| `DEBUG` | bool | False | Режим отладки (включает auto-reload в uvicorn) |

---

## 🌐 API сервер

| Переменная | Тип | По умолчанию | Назначение |
|------------|-----|--------------|------------|
| `HOST` | str | "0.0.0.0" | Хост для привязки сервера |
| `PORT` | int | 8000 | Порт сервера |
| `CORS_ORIGINS` | list[str] | ["*"] | Разрешённые origins для CORS (JSON массив) |

---

## 🌍 Tourvisor API

| Переменная | Тип | По умолчанию | Назначение |
|------------|-----|--------------|------------|
| `TOURVISOR_API_KEY` | str | "" | **DEPRECATED** — использовать AUTH_LOGIN/AUTH_PASS |
| `TOURVISOR_AUTH_LOGIN` | str | "" | Логин для авторизации в Tourvisor API |
| `TOURVISOR_AUTH_PASS` | str | "" | Пароль для авторизации в Tourvisor API |
| `TOURVISOR_BASE_URL` | str | "http://tourvisor.ru/xml" | Базовый URL Tourvisor XML API |
| `TOURVISOR_TIMEOUT` | int | 30 | Таймаут HTTP-запросов в секундах |
| `TOURVISOR_MOCK` | bool | True | Mock-режим (без реальных запросов к API) |

**⚠️ Важно:** Для работы с реальным API установите `TOURVISOR_MOCK=false` и заполните `TOURVISOR_AUTH_LOGIN` и `TOURVISOR_AUTH_PASS`.

---

## 🤖 YandexGPT API

| Переменная | Тип | По умолчанию | Назначение |
|------------|-----|--------------|------------|
| `YANDEX_FOLDER_ID` | str | "" | Folder ID из Yandex Cloud Console |
| `YANDEX_API_KEY` | str | "" | API-ключ сервисного аккаунта Yandex Cloud |
| `YANDEX_MODEL` | str | "yandexgpt-lite" | Модель YandexGPT (yandexgpt-lite, yandexgpt) |
| `YANDEX_GPT_ENABLED` | bool | False | Включение YandexGPT (иначе используется mock) |

---

## 🔍 Настройки поиска

| Переменная | Тип | По умолчанию | Назначение |
|------------|-----|--------------|------------|
| `DEFAULT_NIGHTS_MIN` | int | 7 | Минимум ночей по умолчанию |
| `DEFAULT_NIGHTS_MAX` | int | 14 | Максимум ночей по умолчанию |
| `MAX_TOUR_OFFERS` | int | 5 | Максимум карточек туров в выдаче |

---

## 📝 Где используются переменные

### config.py (Pydantic Settings)
```python
# app/core/config.py
class Settings(BaseSettings):
    TOURVISOR_AUTH_LOGIN: str = ""
    TOURVISOR_AUTH_PASS: str = ""
    # ... и т.д.
```

### Прямые вызовы os.getenv (тесты)

| Файл | Переменная | Назначение |
|------|------------|------------|
| `tests/test_scenarios.py` | `TOURVISOR_MOCK` | Проверка режима для тестов |
| `tests/test_real_connection.py` | `TOURVISOR_*` | Диагностика подключения |
| `debug_final_universal.py` | `TOURVISOR_MOCK` | Отключение mock для debug |

---

## 🛡️ Секреты (НЕ коммитить!)

Следующие переменные содержат **секретные данные** и НЕ должны попадать в репозиторий:

- `TOURVISOR_AUTH_LOGIN`
- `TOURVISOR_AUTH_PASS`
- `TOURVISOR_API_KEY` (deprecated)
- `YANDEX_FOLDER_ID`
- `YANDEX_API_KEY`

Используйте:
- `.env` файл (добавлен в `.gitignore`)
- Системные переменные окружения
- Секреты CI/CD (GitHub Secrets, GitLab CI Variables)

---

## 📄 Пример .env файла

См. файл `env.example` в корне проекта.
