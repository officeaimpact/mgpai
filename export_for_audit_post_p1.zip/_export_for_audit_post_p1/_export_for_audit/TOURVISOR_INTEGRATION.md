# TOURVISOR INTEGRATION — Интеграция с Tourvisor API

## 📡 Используемые endpoints

### Основные endpoints (tourvisor.ru/xml)

| Endpoint | Метод | Назначение | Где используется |
|----------|-------|------------|------------------|
| `search.php` | GET | Инициация асинхронного поиска туров | `app/services/tourvisor.py::search_tours()` |
| `result.php` | GET | Получение статуса/результатов поиска | `app/services/tourvisor.py::_poll_and_fetch_results()` |
| `list.php` | GET | Справочники (страны, города, отели, услуги) | `app/services/tourvisor.py`, `scripts/sync_tourvisor_data.py` |
| `hottours.php` | GET | Горящие туры (синхронный метод) | `app/services/tourvisor.py::get_hot_tours()` |
| `actualize.php` | GET | Актуализация цены конкретного тура | `app/services/tourvisor.py::actualize_tour()` |
| `actdetail.php` | GET | Детали рейса (расписание, авиакомпания) | `app/services/tourvisor.py::get_flight_details()` |
| `hotel.php` | GET | Контент отеля (описание, фото, координаты) | `app/services/tourvisor.py::get_hotel_details()` |

---

## 🔄 Протокол асинхронного поиска

Tourvisor использует асинхронный протокол для search.php:

```
1. GET search.php с параметрами
   └─► Получаем requestid
   
2. Цикл опроса (каждые 2 сек):
   GET result.php?type=status&requestid=XXX
   └─► Проверяем progress (0-100%)
   
3. Когда progress >= 70%:
   GET result.php?type=result&requestid=XXX&page=1&onpage=100
   └─► Получаем список туров
```

**Конфигурация поллинга** (в TourvisorService):
- `poll_interval`: 2.0 сек между запросами
- `max_poll_attempts`: 60 (~120 сек максимум)
- `min_progress_to_fetch`: 70% для начала выгрузки
- `min_wait_seconds`: 25.0 сек минимум (GDS грузится долго!)

---

## 📚 Справочники (list.php)

### Типы справочников

| type= | Назначение | Пример |
|-------|------------|--------|
| `country` | Список стран | Египет (ID=1), Турция (ID=4) |
| `departure` | Города вылета | Москва (ID=1), СПб (ID=2) |
| `region` | Регионы страны | Шарм-эль-Шейх, Хургада |
| `subregion` | Подрегионы | Конкретные курорты |
| `hotel` | Отели страны | list.php?type=hotel&hotcountry=1 |
| `services` | Услуги отелей | 1-я линия, аквапарк, песчаный пляж |
| `meal` | Типы питания | RO, BB, HB, FB, AI, UAI |

### Sync скрипт

**Путь:** `scripts/sync_tourvisor_data.py`

**Запуск:**
```bash
python scripts/sync_tourvisor_data.py
```

**Что делает:**
1. Скачивает list.php?type=country → справочник стран
2. Скачивает list.php?type=departure → города вылета
3. Скачивает list.php?type=services → услуги отелей
4. Генерирует Python-файл: `app/core/tourvisor_constants.py`

**Автоматический запуск:**
- При старте приложения (если файл отсутствует/устарел)
- Каждые 24 часа через APScheduler

### Файл констант

**Путь:** `app/core/tourvisor_constants.py`

**Содержимое:**
```python
COUNTRIES: dict[str, int] = {
    "египет": 1,
    "турция": 4,
    # ...
}

DEPARTURES: dict[str, int] = {
    "москва": 1,
    "санкт-петербург": 2,
    "питер": 2,  # алиас
    # ...
}

SERVICES: dict[str, int] = {
    "первая береговая линия": 1,
    "песчаный пляж": 2,
    # ...
}
```

---

## 🔍 Обязательные параметры запросов

### search.php

| Параметр | Обязательный | Описание |
|----------|--------------|----------|
| `authlogin` | ✅ | Логин авторизации |
| `authpass` | ✅ | Пароль авторизации |
| `country` | ✅ | ID страны назначения |
| `departure` | ✅ | ID города вылета |
| `datefrom` | ✅ | Дата начала поиска (DD.MM.YYYY) |
| `dateto` | ✅ | Дата окончания поиска (DD.MM.YYYY) |
| `nightsfrom` | ✅ | Минимум ночей |
| `nightsto` | ✅ | Максимум ночей |
| `adults` | ✅ | Количество взрослых (1-6) |
| `format` | ✅ | Формат ответа (json) |
| `children` | ❌ | Возрасты детей через запятую (2,5,10) |
| `starsfrom` | ❌ | Минимум звёзд отеля |
| `starsto` | ❌ | Максимум звёзд отеля |
| `meal` | ❌ | ID типа питания |
| `hotel` | ❌ | ID конкретного отеля (для точного поиска) |
| `region` | ❌ | ID региона |
| `services` | ❌ | ID услуг через запятую |
| `hoteltypes` | ❌ | Тип отеля (family, beach, deluxe...) |

### hottours.php

| Параметр | Обязательный | Описание |
|----------|--------------|----------|
| `authlogin` | ✅ | Логин авторизации |
| `authpass` | ✅ | Пароль авторизации |
| `country` | ✅ | ID страны |
| `departure` | ✅ | ID города вылета |
| `format` | ✅ | Формат ответа (json) |
| `datefrom` | ❌ | Начало периода |
| `dateto` | ❌ | Конец периода |

### list.php

| Параметр | Обязательный | Описание |
|----------|--------------|----------|
| `authlogin` | ✅ | Логин авторизации |
| `authpass` | ✅ | Пароль авторизации |
| `type` | ✅ | Тип справочника (country/departure/hotel/region/...) |
| `format` | ✅ | Формат ответа (json) |
| `hotcountry` | ❌* | ID страны для отелей (*обязателен при type=hotel) |
| `regcountry` | ❌* | ID страны для регионов (*обязателен при type=region) |

---

## 📁 Структура кода интеграции

```
app/
├── services/
│   └── tourvisor.py          # TourvisorService (2000+ строк)
│       ├── search_tours()    # Асинхронный поиск
│       ├── get_hot_tours()   # Горящие туры
│       ├── find_hotel_by_name()  # Поиск отеля
│       ├── get_country_id()  # Резолв страны
│       ├── get_departure_id() # Резолв города
│       ├── get_regions()     # Справочник регионов
│       ├── get_hotels_by_country() # Отели страны
│       ├── actualize_tour()  # Актуализация цены
│       ├── get_flight_details() # Детали рейса
│       └── get_hotel_details() # Контент отеля
│
├── core/
│   └── tourvisor_constants.py  # Авто-генерируемые справочники
│
scripts/
└── sync_tourvisor_data.py    # Скрипт синхронизации
    ├── fetch_countries()
    ├── fetch_departures()
    ├── fetch_services()
    └── generate_constants_file()
```

---

## ⚠️ Особенности и ограничения

### 1. GDS-рейсы грузятся долго
Регулярные рейсы (GDS) требуют 20-40+ секунд для загрузки. Не прерывайте поиск раньше времени!

### 2. Фильтрация звёзд на клиенте
API не гарантирует соответствие параметру `starsfrom`. Необходима клиентская фильтрация:
```python
if params.stars:
    offers = [o for o in offers if o.stars and o.stars >= params.stars]
```

### 3. Fuzzy matching для городов
Используется библиотека `thefuzz` для нечёткого поиска:
- "Питер" → "Санкт-Петербург"
- "СПб" → "Санкт-Петербург"
- "Екб" → "Екатеринбург"

### 4. Кэширование справочников
Справочники кэшируются в памяти после первой загрузки (in-memory cache в TourvisorService).

---

## 🔗 Документация Tourvisor API

- Официальная документация: [tourvisor.ru/api/](https://tourvisor.ru/api/)
- Получение ключей: регистрация на tourvisor.ru → раздел API
