"""Scripts package for MGP AI."""
