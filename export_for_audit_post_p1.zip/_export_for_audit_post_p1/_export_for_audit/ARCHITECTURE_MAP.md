# ARCHITECTURE MAP — Архитектура ИИ-Ассистента МГП

## 🏗️ Общая архитектура

```
┌─────────────────┐     HTTP      ┌──────────────────────────────────────────┐
│   Frontend      │◄─────────────►│           Backend (FastAPI)              │
│  (Widget Chat)  │               │                                          │
│  index.html     │               │  ┌──────────────────────────────────┐   │
│  script.js      │               │  │         LangGraph Agent          │   │
│  styles.css     │               │  │  (State Machine + Slot Filling)  │   │
└─────────────────┘               │  └──────────────────────────────────┘   │
                                  │                  │                       │
                                  │                  ▼                       │
                                  │  ┌──────────────────────────────────┐   │
                                  │  │       Tourvisor API Service      │   │
                                  │  │   (Поиск туров, справочники)     │   │
                                  │  └──────────────────────────────────┘   │
                                  └──────────────────────────────────────────┘
                                                     │
                                                     ▼
                                         ┌─────────────────────┐
                                         │   Tourvisor XML API │
                                         │   tourvisor.ru/xml  │
                                         └─────────────────────┘
```

---

## 📁 Ключевые файлы и их назначение

### 1. Логика диалога / LangGraph

| Файл | Назначение |
|------|------------|
| `app/agent/graph.py` | **Конструктор StateGraph** — собирает узлы и рёбра графа, определяет условные переходы |
| `app/agent/nodes.py` | **Узлы графа** — slot_filler, responder, tour_searcher, fallback_handler |
| `app/agent/state.py` | **AgentState TypedDict** — определение всех полей состояния диалога |
| `app/agent/runner.py` | **Запуск графа** — обёртка для invoke с checkpointer |
| `app/agent/state_machine.py` | **Вспомогательная логика** — определение режимов поиска (package/hotel_only/burning) |

### 2. Сбор параметров (Slots / Квалификация)

| Где | Что |
|-----|-----|
| `app/agent/nodes.py::slot_filler()` | Основная функция извлечения слотов из сообщения пользователя |
| `app/agent/nodes.py::get_cascade_stage()` | Определение этапа каскада вопросов (1-5) |
| `app/agent/nodes.py::responder()` | Генерация уточняющих вопросов на основе текущего этапа |
| `app/agent/state.py::PartialSearchParams` | TypedDict со всеми слотами (adults, children, destination_country, и т.д.) |

**Каскад вопросов (железная логика):**
1. **Куда?** — страна/регион назначения
2. **Откуда?** — город вылета (обязательно!)
3. **Когда?** — даты поездки или количество ночей
4. **Кто едет?** — количество взрослых + дети с возрастами
5. **Детали** — звёзды отеля, тип питания, услуги

### 3. Интеграция Tourvisor API

| Файл | Назначение |
|------|------------|
| `app/services/tourvisor.py` | **TourvisorService** — полная реализация API протокола |
| `app/core/tourvisor_constants.py` | **Авто-генерируемые константы** — справочники стран, городов, услуг |
| `scripts/sync_tourvisor_data.py` | **Скрипт синхронизации** — скачивает справочники из API |

**Ключевые методы TourvisorService:**
- `search_tours()` — асинхронный поиск туров (search.php + result.php)
- `get_hot_tours()` — горящие туры (hottours.php)
- `find_hotel_by_name()` — поиск отеля по имени
- `get_country_id()` — резолв страны в ID
- `get_departure_id()` — резолв города вылета в ID
- `actualize_tour()` — актуализация цены конкретного тура

### 4. Формирование карточек туров

| Где | Что |
|-----|-----|
| `app/agent/nodes.py::tour_searcher()` | Вызов TourvisorService и формирование SearchResponse |
| `app/agent/nodes.py::format_tour_offers()` | Форматирование туров в текстовый ответ для пользователя |
| `app/models/domain.py::TourOffer` | Pydantic-модель карточки тура |
| `app/models/domain.py::SearchResponse` | Ответ поиска (список TourOffer + метаданные) |

**Бизнес-правило:** Выдаётся 3-5 релевантных карточек (настраивается через `MAX_TOUR_OFFERS`).

### 5. Системные промпты

| Файл | Назначение |
|------|------------|
| `app/agent/prompts.py` | Все системные инструкции для LLM |
| `system_prompt.md` | Читаемая версия системного промпта (для документации) |

---

## 🔄 Поток данных

```
1. User Message
       │
       ▼
2. POST /api/v1/chat
       │
       ▼
3. LangGraph.invoke(state)
       │
       ├─► slot_filler() → извлечение параметров
       │
       ├─► get_cascade_stage() → определение этапа
       │
       ├─► responder() → уточняющий вопрос ИЛИ запуск поиска
       │        │
       │        ▼
       │   tour_searcher() → вызов Tourvisor API
       │        │
       │        ▼
       │   format_tour_offers() → карточки туров
       │
       ▼
4. Response {message, session_id, search_results?}
```

---

## 🗄️ Состояние (AgentState)

```python
class AgentState(TypedDict):
    # История диалога
    messages: list[BaseMessage]
    
    # Извлечённые параметры поиска
    search_params: PartialSearchParams
    
    # Режим поиска
    search_mode: Literal["package", "hotel_only", "burning"]
    
    # Результаты поиска
    search_results: Optional[list[TourOffer]]
    
    # Флаги
    is_ready_to_search: bool
    date_warning: bool  # если точная дата недоступна
    
    # Сессия
    thread_id: str
```

---

## 🔌 REST API Endpoints

| Метод | Путь | Назначение |
|-------|------|------------|
| GET | `/` | Информация о сервисе |
| GET | `/health` | Healthcheck |
| POST | `/api/v1/chat` | Основной endpoint чата |

**POST /api/v1/chat:**
```json
// Request
{
  "message": "Хочу в Египет на неделю",
  "session_id": "user-123-abc"
}

// Response
{
  "message": "Отлично! Из какого города вылетаете?",
  "session_id": "user-123-abc",
  "search_results": null
}
```

---

## 📦 Pydantic модели (app/models/domain.py)

| Модель | Назначение |
|--------|------------|
| `SearchRequest` | Параметры запроса на поиск туров |
| `TourOffer` | Карточка одного тура |
| `SearchResponse` | Результат поиска (список туров) |
| `Destination` | Направление (страна, регион, курорт) |
| `TourFilters` | Фильтры (звёзды, питание, услуги) |
| `HotelDetails` | Детали отеля |
| `FoodType` | Enum типов питания (RO, BB, HB, FB, AI, UAI) |

---

## 🛡️ Guardrails и безопасность

| Файл | Назначение |
|------|------------|
| `app/core/guardrails.py` | Input/Output валидация, защита от Prompt Injection |

**Правила:**
- Input Guardrails: валидация входящих сообщений
- Output Guardrails: скрытие технических ошибок от пользователя
- Human-in-the-loop: бронирование требует явного подтверждения
