# RUNBOOK — Инструкция по запуску МГП ИИ-Ассистента

## 📋 Требования

### Python
- **Версия:** Python 3.11+
- **Менеджер пакетов:** pip (или poetry)

### Node.js (опционально для разработки)
- **Версия:** Node.js 18+ (если нужен dev-сервер для фронтенда)

---

## 🚀 Быстрый старт

### 1. Клонирование / подготовка

```bash
cd /path/to/project
```

### 2. Создание виртуального окружения

```bash
python3.11 -m venv .venv
source .venv/bin/activate  # Linux/macOS
# .venv\Scripts\activate   # Windows
```

### 3. Установка зависимостей

```bash
pip install -r requirements.txt
```

### 4. Настройка переменных окружения

```bash
cp env.example .env
# Отредактируйте .env, заполнив реальные значения
```

**Минимальный набор переменных для работы:**
```env
TOURVISOR_AUTH_LOGIN=your_login
TOURVISOR_AUTH_PASS=your_password
TOURVISOR_MOCK=false

# Если используете YandexGPT:
YANDEX_FOLDER_ID=your_folder_id
YANDEX_API_KEY=your_api_key
YANDEX_GPT_ENABLED=true
```

### 5. Синхронизация справочников Tourvisor (первый запуск)

```bash
python scripts/sync_tourvisor_data.py
```

Это создаст файл `app/core/tourvisor_constants.py` с актуальными данными стран и городов.

### 6. Запуск Backend (FastAPI)

```bash
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

**Альтернатива:**
```bash
python -m app.main
```

После запуска:
- API доступен по адресу: `http://localhost:8000`
- Swagger UI: `http://localhost:8000/docs`
- ReDoc: `http://localhost:8000/redoc`

### 7. Запуск Frontend

Frontend — статические файлы (HTML/CSS/JS). Способы запуска:

**Вариант A: Через Python http.server**
```bash
cd frontend
python -m http.server 3000
# Открыть http://localhost:3000
```

**Вариант B: Live Server в VS Code**
- Установите расширение "Live Server"
- Откройте `frontend/index.html`
- Нажмите "Go Live"

**Вариант C: Через nginx/apache**
- Настройте web-сервер на директорию `frontend/`

---

## 🧪 Тестирование

### Запуск тестов

```bash
# Все тесты
python -m pytest tests/

# Конкретный тест
python -m pytest tests/test_scenarios.py -v

# Smoke-тест сессий
python -m pytest tests/test_smoke_persistence.py -v
```

### Ручное тестирование API

```bash
# Проверка здоровья
curl http://localhost:8000/health

# Отправка сообщения в чат
curl -X POST http://localhost:8000/api/v1/chat \
  -H "Content-Type: application/json" \
  -d '{"message": "Хочу в Египет на неделю", "session_id": "test-123"}'
```

---

## 📂 Структура проекта

```
.
├── app/                      # Backend (FastAPI)
│   ├── agent/               # LangGraph логика диалога
│   │   ├── graph.py        # Конструктор графа
│   │   ├── nodes.py        # Узлы графа (slot filling, search)
│   │   ├── prompts.py      # Системные промпты
│   │   └── state.py        # Определение состояния
│   ├── api/v1/endpoints/   # REST API endpoints
│   ├── core/               # Конфигурация, константы
│   ├── models/             # Pydantic модели
│   └── services/           # Интеграции (Tourvisor API)
├── frontend/                # Статический виджет чата
├── scripts/                 # Утилиты синхронизации
├── tests/                   # Тесты
├── requirements.txt         # Python зависимости
└── env.example             # Пример .env файла
```

---

## ⚠️ Частые проблемы

### 1. "ModuleNotFoundError: No module named 'app'"
**Решение:** Запускайте из корня проекта, не из вложенных папок.

### 2. "Tourvisor API timeout"
**Решение:** Увеличьте `TOURVISOR_TIMEOUT` в .env (например, 60 секунд).

### 3. "thefuzz не установлен"
**Решение:** `pip install thefuzz[speedup]`

### 4. "CORS ошибки в браузере"
**Решение:** Добавьте URL фронтенда в `CORS_ORIGINS` в .env.

---

## 📅 Периодические задачи

| Задача | Частота | Команда |
|--------|---------|---------|
| Синхронизация справочников | Авто (24ч) | Встроено в app.main |
| Ручная синхронизация | По необходимости | `python scripts/sync_tourvisor_data.py` |

---

## 📞 Контакты

Для вопросов по аудиту обращайтесь к команде разработки MGP AI.
