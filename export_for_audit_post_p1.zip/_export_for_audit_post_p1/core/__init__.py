"""Конфигурация и настройки приложения."""

from core.config import settings

__all__ = ["settings"]
